package aethereal.setting;

import java.util.function.Supplier;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    protected Supplier<Boolean> visible = () -> Boolean.TRUE;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public T c() {
        return value;
    }

    public void set(T v) {
        this.value = v;
    }

    /** Условие видимости (в этой сборке нет меню, поэтому просто сохраняем). */
    public Setting<T> a(Supplier<Boolean> v) {
        this.visible = v;
        return this;
    }

    public boolean isVisible() {
        return visible.get();
    }
}
