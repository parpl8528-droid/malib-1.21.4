package aethereal.setting;

public class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, Boolean def) {
        super(name, def);
    }
}
