package aethereal.setting;

public class ModeSetting extends Setting<String> {
    public final String[] modes;

    public ModeSetting(String name, String def, String[] modes) {
        super(name, def);
        this.modes = modes;
    }

    public boolean l(String mode) {
        return value != null && value.equals(mode);
    }
}
