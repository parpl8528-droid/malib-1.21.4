package aethereal.setting;

public class SliderSetting extends Setting<Float> {
    public final float min, max, step;

    public SliderSetting(String name, float def, float min, float max, float step) {
        super(name, def);
        this.min = min;
        this.max = max;
        this.step = step;
    }
}
