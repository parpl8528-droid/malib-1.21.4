package aethereal.setting;

import java.util.ArrayList;
import java.util.List;

public class MultiModeSetting extends Setting<List<BooleanSetting>> {
    public MultiModeSetting(String name, BooleanSetting[] items) {
        super(name, new ArrayList<>(List.of(items)));
    }

    public BooleanSetting a(String n) {
        for (BooleanSetting b : value) {
            if (b.name.equals(n)) return b;
        }
        return null;
    }
}
