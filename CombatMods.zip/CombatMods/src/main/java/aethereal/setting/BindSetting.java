package aethereal.setting;

import aethereal.core.Action;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

/** Кнопка внутри модуля: появляется в Настройки -> Управление -> Combat Mods. */
public class BindSetting extends Setting<Integer> {
    public static final List<BindSetting> ALL = new ArrayList<>();
    private static int counter = 0;

    public final KeyBinding key;
    private Action onPress = () -> {};
    private Action onRelease = () -> {};
    private boolean wasDown;

    public BindSetting(String name, Integer defKey, int mode) {
        super(name, defKey);
        this.key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combatmods.bind" + (counter++), InputUtil.Type.KEYSYM,
                defKey == null ? InputUtil.UNKNOWN_KEY.getCode() : defKey, "key.categories.combatmods"));
        ALL.add(this);
    }

    public BindSetting a(Action press) {
        this.onPress = press;
        return this;
    }

    public BindSetting b(Action release) {
        this.onRelease = release;
        return this;
    }

    public void tick() {
        boolean down = key.isPressed();
        if (down && !wasDown) onPress.execute();
        if (!down && wasDown) onRelease.execute();
        wasDown = down;
    }
}
