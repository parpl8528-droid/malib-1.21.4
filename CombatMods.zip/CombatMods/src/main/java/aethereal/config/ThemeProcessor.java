package aethereal.config;

public class ThemeProcessor {
    public ThemeConstructor a(ThemeInfo info) {
        return new ThemeConstructor(info == ThemeInfo.PRIMARY ? 0xFF8A7CFF : 0xFF5B4FD6);
    }
}
