package aethereal.config;

import aethereal.setting.*;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** config/combatmods.json: состояние модулей и все их настройки. Правится любым текстовым редактором. */
public final class SettingStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("combatmods.json");
    private static JsonObject root = new JsonObject();

    static {
        try {
            if (Files.exists(FILE)) {
                JsonElement e = JsonParser.parseString(Files.readString(FILE));
                if (e.isJsonObject()) root = e.getAsJsonObject();
            }
        } catch (Exception ex) {
            System.err.println("[CombatMods] Не удалось прочитать конфиг: " + ex);
        }
    }

    private SettingStore() {}

    private static JsonObject mod(String module) {
        JsonElement e = root.get(module);
        if (e == null || !e.isJsonObject()) {
            JsonObject o = new JsonObject();
            root.add(module, o);
            return o;
        }
        return e.getAsJsonObject();
    }

    public static boolean isEnabled(String module) {
        JsonElement e = mod(module).get("enabled");
        return e != null && e.isJsonPrimitive() && e.getAsBoolean();
    }

    public static void setEnabled(String module, boolean v) {
        mod(module).addProperty("enabled", v);
        save();
    }

    public static boolean getHud() {
        JsonElement e = root.get("hud");
        return e == null || !e.isJsonPrimitive() || e.getAsBoolean();
    }

    public static void setHud(boolean v) {
        root.addProperty("hud", v);
        save();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void load(String module, Setting<?> s) {
        JsonObject m = mod(module);
        try {
            JsonElement e = m.get(s.name);
            if (e != null && !e.isJsonNull()) {
                if (s instanceof BooleanSetting b) {
                    b.set(e.getAsBoolean());
                } else if (s instanceof SliderSetting sl) {
                    sl.set(e.getAsFloat());
                } else if (s instanceof ModeSetting ms) {
                    ms.set(e.getAsString());
                } else if (s instanceof MultiModeSetting mm && e.isJsonObject()) {
                    JsonObject o = e.getAsJsonObject();
                    for (BooleanSetting b : mm.c()) {
                        if (o.has(b.name)) b.set(o.get(b.name).getAsBoolean());
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("[CombatMods] Неверное значение настройки " + module + "/" + s.name + ": " + ex);
        }
        // записываем текущие значения, чтобы в файле были все настройки
        if (s instanceof BooleanSetting b) m.addProperty(s.name, b.c());
        else if (s instanceof SliderSetting sl) m.addProperty(s.name, sl.c());
        else if (s instanceof ModeSetting ms) m.addProperty(s.name, ms.c());
        else if (s instanceof MultiModeSetting mm) {
            JsonObject o = new JsonObject();
            for (BooleanSetting b : mm.c()) o.addProperty(b.name, b.c());
            m.add(s.name, o);
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(root));
        } catch (Exception ex) {
            System.err.println("[CombatMods] Не удалось сохранить конфиг: " + ex);
        }
    }
}
