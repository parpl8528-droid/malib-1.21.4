package aethereal.config;

import aethereal.core.Module;
import aethereal.module.combat.*;
import aethereal.module.movement.ElytraTarget;
import aethereal.module.player.ElytraHelper;

import java.util.ArrayList;
import java.util.List;

public class ModuleProcessor {
    public static final ModuleProcessor INSTANCE = new ModuleProcessor();

    public final List<Module> modules = new ArrayList<>();
    private Aura aura;
    private TriggerBot triggerBot;
    private AutoTotem autoTotem;
    private final ProjectileHelper projectileHelper = new ProjectileHelper();
    private final MaceHelper maceHelper = new MaceHelper();
    private final ElytraHelper elytraHelper = new ElytraHelper();
    private final ElytraTarget elytraTarget = new ElytraTarget();

    /** Создаёт оригинальные модули. Вызывается один раз при старте. */
    public void init() {
        aura = add(new Aura());
        add(new AimAssistant());
        triggerBot = add(new TriggerBot());
        autoTotem = add(new AutoTotem());
        add(new AutoArmor());
        add(new AutoSwap());
    }

    private <T extends Module> T add(T m) {
        modules.add(m);
        return m;
    }

    public Aura B() { return aura; }
    public ProjectileHelper D() { return projectileHelper; }
    public ElytraHelper F() { return elytraHelper; }
    public ElytraTarget G() { return elytraTarget; }
    public MaceHelper H() { return maceHelper; }
    public AutoTotem V() { return autoTotem; }
    public TriggerBot X() { return triggerBot; }
}
