package aethereal.config;

public class ThemeConstructor {
    private final int color;

    public ThemeConstructor(int color) {
        this.color = color;
    }

    public int a() {
        return color;
    }
}
