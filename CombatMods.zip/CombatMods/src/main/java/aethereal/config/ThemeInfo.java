package aethereal.config;

public enum ThemeInfo { PRIMARY, SECONDARY }
