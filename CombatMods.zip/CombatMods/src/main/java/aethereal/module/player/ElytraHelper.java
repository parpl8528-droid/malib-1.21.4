package aethereal.module.player;

import aethereal.core.Module;

public class ElytraHelper extends Module {
    public ElytraHelper() {}
}
