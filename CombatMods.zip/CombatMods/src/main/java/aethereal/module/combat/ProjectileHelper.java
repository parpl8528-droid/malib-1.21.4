package aethereal.module.combat;

import aethereal.core.Module;
import net.minecraft.entity.LivingEntity;

/** Помощник снарядов: в этой сборке выключен. */
public class ProjectileHelper extends Module {
    public ProjectileHelper() {}

    public LivingEntity q() { return null; }

    public boolean r() { return false; }
}
