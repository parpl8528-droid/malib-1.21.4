package aethereal.module.combat;

import aethereal.core.Module;

/** Заглушка для компиляции. В готовом моде заменяется оригинальным классом. */
public class AutoSwap extends Module {
    public AutoSwap() {}
}
