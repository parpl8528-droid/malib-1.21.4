package aethereal.module.combat;

import aethereal.core.Module;
import aethereal.setting.BooleanSetting;

/** Помощник булавы: в этой сборке выключен. */
public class MaceHelper extends Module {
    public BooleanSetting b = new BooleanSetting("b", false);
    public BooleanSetting c = new BooleanSetting("c", false);
    public boolean e = false;

    public MaceHelper() {}
}
