package aethereal.module.combat;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.setting.BooleanSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * TriggerBot: бьёт цель, на которую наведён прицел.
 * Бьёт, когда перезарядка оружия готова; в режиме "Только криты" - на падении (прыжок).
 */
@ModuleRegister(a = "TriggerBot", b = "Автоматически бьёт цель под прицелом", c = Category.Combat)
public class TriggerBot extends Module {
    public int d;
    private LivingEntity target;

    private final BooleanSetting critsOnly = new BooleanSetting("Только криты", false);
    private final BooleanSetting players = new BooleanSetting("Игроки", true);
    private final BooleanSetting mobs = new BooleanSetting("Мобы", true);
    private final BooleanSetting animals = new BooleanSetting("Животные", false);

    public TriggerBot() {
        a(critsOnly, players, mobs, animals);
    }

    public int r() {
        return d;
    }

    public LivingEntity s() {
        return target;
    }

    @Override
    public void c() {
        target = null;
        d = 0;
    }

    private boolean valid(Entity e) {
        if (!(e instanceof LivingEntity le) || !le.isAlive() || le == aM_.player) return false;
        if (le instanceof PlayerEntity p) return players.c() && !p.isSpectator();
        if (le instanceof net.minecraft.entity.mob.Monster) return mobs.c();
        return animals.c();
    }

    @EventTarget
    public void a(TickEvent event) {
        var p = aM_.player;
        if (p == null || aM_.world == null || aM_.interactionManager == null) return;
        d++;
        target = null;
        if (aM_.currentScreen != null) return;

        HitResult hr = aM_.crosshairTarget;
        if (hr == null || hr.getType() != HitResult.Type.ENTITY) return;
        Entity e = ((EntityHitResult) hr).getEntity();
        if (!valid(e)) return;
        target = (LivingEntity) e;

        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;

        if (critsOnly.c()) {
            boolean falling = !p.isOnGround() && p.fallDistance > 0.0f && p.getVelocity().y < 0
                    && !p.isTouchingWater() && !p.isClimbing() && !p.hasVehicle();
            if (!falling) return;
        }

        aM_.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        d = 0;
    }
}
