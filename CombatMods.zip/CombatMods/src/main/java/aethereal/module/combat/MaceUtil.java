package aethereal.module.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.world.World;

import java.util.Optional;

public final class MaceUtil {
    private MaceUtil() {}

    public static boolean a() { return false; }

    public static boolean b() { return false; }

    public static Optional<Object> a(ClientPlayerEntity player, World world) {
        return Optional.empty();
    }
}
