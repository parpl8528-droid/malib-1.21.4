package aethereal.module.combat;

import aethereal.handler.BaseHandler;

/** Заглушка для компиляции. В готовом моде заменяется оригинальным классом. */
public class AuraHandler extends BaseHandler {
    public AuraHandler() {}
}
