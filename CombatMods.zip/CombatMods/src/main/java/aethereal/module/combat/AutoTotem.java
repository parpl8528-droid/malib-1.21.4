package aethereal.module.combat;

import aethereal.core.Module;

/** Заглушка для компиляции. В готовом моде заменяется оригинальным классом. */
public class AutoTotem extends Module {
    public AutoTotem() {}
}
