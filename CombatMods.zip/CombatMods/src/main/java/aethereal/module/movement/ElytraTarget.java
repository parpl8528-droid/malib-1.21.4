package aethereal.module.movement;

import aethereal.core.Module;

public class ElytraTarget extends Module {
    public ElytraTarget() {}
}
