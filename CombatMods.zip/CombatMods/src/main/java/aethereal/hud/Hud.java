package aethereal.hud;

import aethereal.config.ModuleProcessor;
import aethereal.config.SettingStore;
import aethereal.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Отдельный HUD: список включённых модулей справа сверху. Кнопка "Toggle HUD" в Управлении. */
public final class Hud {
    private static final int[] COLORS = {0xFF55FFFF, 0xFF55FF55, 0xFFFFFF55, 0xFFFF55FF, 0xFFFFAA00, 0xFFFF5555};

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!SettingStore.getHud() || mc.player == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int screenW = ctx.getScaledWindowWidth();

        List<String> names = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        int idx = 0;
        for (Module m : ModuleProcessor.INSTANCE.modules) {
            int color = COLORS[idx++ % COLORS.length];
            if (!m.m()) continue;
            names.add(m.name);
            colors.add(color);
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        order.sort(Comparator.comparingInt((Integer i) -> tr.getWidth(names.get(i))).reversed());

        int y = 4;
        for (int i : order) {
            String s = names.get(i);
            int w = tr.getWidth(s);
            int x = screenW - w - 4;
            ctx.fill(x - 2, y - 1, screenW - 2, y + tr.fontHeight, 0x90000000);
            ctx.fill(screenW - 3, y - 1, screenW - 2, y + tr.fontHeight, colors.get(i));
            ctx.drawTextWithShadow(tr, s, x, y, colors.get(i));
            y += tr.fontHeight + 2;
        }
    }
}
