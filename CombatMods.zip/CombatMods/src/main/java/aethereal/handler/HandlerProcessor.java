package aethereal.handler;

public class HandlerProcessor {
    private final InventoryHandler inventory = new InventoryHandler();

    public InventoryHandler a() {
        return inventory;
    }
}
