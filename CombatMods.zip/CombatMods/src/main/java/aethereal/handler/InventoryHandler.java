package aethereal.handler;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;
import java.util.List;

/**
 * Работа с инвентарём. Номера слотов - индексы инвентаря игрока:
 * 0..8 хотбар, 9..35 основной инвентарь, 40 - вторая рука.
 */
public class InventoryHandler {
    private final List<Object> queue = new ArrayList<>();

    /** Очередь отложенных действий (у нас действия выполняются сразу, поэтому всегда пуста). */
    public List<Object> a() {
        return queue;
    }

    private static int container(int invIndex) {
        if (invIndex >= 0 && invIndex < 9) return 36 + invIndex;
        if (invIndex == 40 || invIndex == 45) return 45;
        return invIndex;
    }

    /** Обмен предмета из слота with с хотбаром (button 0..8) или второй рукой (button 40/45). */
    public void a(int slot, int button, int mode) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || slot < 0) return;
        PlayerScreenHandler h = p.playerScreenHandler;
        int btn = (button == 40 || button == 45) ? 40 : button;
        mc.interactionManager.clickSlot(h.syncId, container(slot), btn, SlotActionType.SWAP, p);
    }

    /** Надеть броню: предмет из слота инвентаря slot на слот брони armorIndex (0 голова .. 3 ботинки). */
    public void b(int slot, int armorIndex, int mode) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || slot < 0) return;
        PlayerScreenHandler h = p.playerScreenHandler;
        int from = container(slot);
        int armorSlot = 5 + armorIndex;
        if (h.getSlot(armorSlot).getStack().isEmpty()) {
            mc.interactionManager.clickSlot(h.syncId, from, 0, SlotActionType.QUICK_MOVE, p);
        } else {
            mc.interactionManager.clickSlot(h.syncId, from, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(h.syncId, armorSlot, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(h.syncId, from, 0, SlotActionType.PICKUP, p);
        }
    }
}
