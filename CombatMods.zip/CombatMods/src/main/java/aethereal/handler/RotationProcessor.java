package aethereal.handler;

import aethereal.util.Rotation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

public class RotationProcessor {
    /**
     * Довернуть взгляд игрока к rotation, максимум speed градусов за вызов.
     */
    public void a(Rotation rotation, float speed, int a, int b) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null || rotation == null) return;
        float dyaw = MathHelper.wrapDegrees(rotation.yaw - p.getYaw());
        float dpitch = rotation.pitch - p.getPitch();
        dyaw = MathHelper.clamp(dyaw, -speed, speed);
        dpitch = MathHelper.clamp(dpitch, -speed, speed);
        p.setYaw(a(p.getYaw(), p.getYaw() + dyaw));
        p.setPitch(MathHelper.clamp(a(p.getPitch(), p.getPitch() + dpitch), -90f, 90f));
    }

    /** Подгонка вращения под шаг мыши (GCD), чтобы повороты выглядели как мышиные. */
    public static float a(float current, float target) {
        double sens = MinecraftClient.getInstance().options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;
        float delta = target - current;
        if (gcd <= 0) return target;
        return current + (float) (Math.round(delta / gcd) * gcd);
    }
}
