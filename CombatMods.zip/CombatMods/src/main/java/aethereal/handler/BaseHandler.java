package aethereal.handler;

public class BaseHandler {
    public BaseHandler() {}
}
