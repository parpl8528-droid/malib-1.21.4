package aethereal.friend;

public class FriendProcessor {
    /** Список друзей пуст. */
    public boolean d(String name) {
        return false;
    }
}
