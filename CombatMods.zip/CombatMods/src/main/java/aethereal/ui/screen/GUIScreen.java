package aethereal.ui.screen;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class GUIScreen extends Screen {
    public GUIScreen(Text title) {
        super(title);
    }

    public GUIScreen() {
        super(Text.literal("GUIScreen"));
    }
}
