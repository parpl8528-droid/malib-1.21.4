package aethereal.ui.screen;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class SwapScreen extends Screen {
    public SwapScreen(Text title) {
        super(title);
    }

    public SwapScreen() {
        super(Text.literal("SwapScreen"));
    }
}
