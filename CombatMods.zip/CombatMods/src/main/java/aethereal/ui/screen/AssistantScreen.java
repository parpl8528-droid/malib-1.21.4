package aethereal.ui.screen;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class AssistantScreen extends Screen {
    public AssistantScreen(Text title) {
        super(title);
    }

    public AssistantScreen() {
        super(Text.literal("AssistantScreen"));
    }
}
