package aethereal;

import aethereal.config.ModuleProcessor;
import aethereal.config.SettingStore;
import aethereal.core.EventBus;
import aethereal.core.GlobalEvent;
import aethereal.core.Module;
import aethereal.event.LookEvent;
import aethereal.event.TickEvent;
import aethereal.event.WillLandEvent;
import aethereal.hud.Hud;
import aethereal.module.combat.AimHandler;
import aethereal.module.combat.AuraHandler;
import aethereal.setting.BindSetting;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;

public class AetherMod implements ClientModInitializer {
    private static KeyBinding hudKey;

    @Override
    public void onInitializeClient() {
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combatmods.hud", InputUtil.Type.KEYSYM, InputUtil.UNKNOWN_KEY.getCode(), "key.categories.combatmods"));

        try {
            ModuleProcessor.INSTANCE.init();
        } catch (Throwable t) {
            System.err.println("[CombatMods] Не удалось создать модули: " + t);
            t.printStackTrace();
        }

        // постоянные обработчики оригинала
        try {
            EventBus.register(new AimHandler());
            EventBus.register(new AuraHandler());
        } catch (Throwable t) {
            System.err.println("[CombatMods] Не удалось создать обработчики: " + t);
            t.printStackTrace();
        }

        for (Module m : ModuleProcessor.INSTANCE.modules) {
            m.applyInitial();
        }

        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            EventBus.post(new GlobalEvent());
            if (mc.player != null && mc.world != null) {
                EventBus.post(new WillLandEvent(willLand(mc.player, mc)));
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(AetherMod::endTick);
        WorldRenderEvents.START.register(ctx -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && mc.world != null) EventBus.post(new LookEvent());
        });
        HudRenderCallback.EVENT.register(Hud::render);
    }

    private static boolean willLand(ClientPlayerEntity p, MinecraftClient mc) {
        if (p.isOnGround() || p.getVelocity().y >= 0) return false;
        Box moved = p.getBoundingBox().offset(0, p.getVelocity().y, 0);
        return !mc.world.isSpaceEmpty(p, moved);
    }

    private static void endTick(MinecraftClient mc) {
        while (hudKey.wasPressed()) {
            boolean v = !SettingStore.getHud();
            SettingStore.setHud(v);
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("HUD " + (v ? "§aON" : "§cOFF")), true);
            }
        }
        for (Module m : ModuleProcessor.INSTANCE.modules) {
            if (m.key == null) continue;
            while (m.key.wasPressed()) {
                m.toggle();
            }
        }
        for (BindSetting b : BindSetting.ALL) {
            b.tick();
        }
        if (mc.player != null && mc.world != null && mc.interactionManager != null) {
            EventBus.post(new TickEvent());
        }
    }
}
