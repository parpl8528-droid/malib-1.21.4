package aethereal.render;

public class AnimationUtil {
    private float value;
    private float target;

    public AnimationUtil() {}

    public float a() { return value; }
    public float c() { return target; }

    public void a(boolean forward) {
        target = forward ? 1f : 0f;
        value = target;
    }

    public void a(float a, float b, float c, EasingList.a easing, float d) {
    }
}
