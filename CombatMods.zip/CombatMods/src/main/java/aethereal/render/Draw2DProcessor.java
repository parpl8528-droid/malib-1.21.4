package aethereal.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class Draw2DProcessor {
    public void a(MatrixStack m, Identifier id, float a, float b, float c, float d, float e, int color) {
    }
}
