package aethereal.render;

public final class ColorUtil {
    private ColorUtil() {}

    /** Умножить прозрачность цвета на alpha (0..1). */
    public static int a(int color, float alpha) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, alpha)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int[] b(int color) {
        return new int[]{(color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, (color >>> 24) & 0xFF};
    }
}
