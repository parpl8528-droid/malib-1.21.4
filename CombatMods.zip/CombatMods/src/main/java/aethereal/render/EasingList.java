package aethereal.render;

public class EasingList {
    public interface a {
        float ease(float t);
    }

    public static final a g = t -> t;
}
