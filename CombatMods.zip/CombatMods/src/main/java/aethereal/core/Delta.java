package aethereal.core;

public class Delta {
    private static final Delta INSTANCE = new Delta();
    private final Processor_2 processor = new Processor_2();

    public static Delta h() {
        return INSTANCE;
    }

    public Processor_2 d() {
        return processor;
    }
}
