package aethereal.core;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public final class EventBus {
    private static final List<Object> LISTENERS = new CopyOnWriteArrayList<>();
    private static final Map<Class<?>, List<Method>> METHODS = new HashMap<>();
    private static final Set<String> REPORTED = new HashSet<>();

    private EventBus() {}

    public static void register(Object o) {
        if (!LISTENERS.contains(o)) LISTENERS.add(o);
    }

    public static void unregister(Object o) {
        LISTENERS.remove(o);
    }

    private static List<Method> handlersOf(Class<?> c) {
        return METHODS.computeIfAbsent(c, k -> {
            List<Method> list = new ArrayList<>();
            for (Method m : k.getMethods()) {
                if (m.isAnnotationPresent(EventTarget.class) && m.getParameterCount() == 1) {
                    m.setAccessible(true);
                    list.add(m);
                }
            }
            return list;
        });
    }

    public static void post(Object event) {
        for (Object l : LISTENERS) {
            for (Method m : handlersOf(l.getClass())) {
                if (m.getParameterTypes()[0].isInstance(event)) {
                    try {
                        m.invoke(l, event);
                    } catch (Throwable t) {
                        Throwable c = t.getCause() != null ? t.getCause() : t;
                        String key = l.getClass().getName() + "#" + m.getName() + ":" + c;
                        if (REPORTED.add(key)) {
                            System.err.println("[CombatMods] Ошибка в " + l.getClass().getSimpleName() + "." + m.getName() + ": " + c);
                            c.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
