package aethereal.core;

import aethereal.config.SettingStore;
import aethereal.setting.Setting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public abstract class Module implements Interface {
    public final String name;
    public final String description;
    public final Category category;
    public final String id;
    public final KeyBinding key;
    public final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;

    public Module() {
        ModuleRegister info = getClass().getAnnotation(ModuleRegister.class);
        if (info != null) {
            name = info.a();
            description = info.b();
            category = info.c();
            id = name.toLowerCase().replaceAll("[^a-z0-9]", "");
            key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.combatmods." + id, InputUtil.Type.KEYSYM, InputUtil.UNKNOWN_KEY.getCode(), "key.categories.combatmods"));
            enabled = SettingStore.isEnabled(name);
        } else {
            name = getClass().getSimpleName();
            description = "";
            category = Category.Misc;
            id = name.toLowerCase();
            key = null;
        }
    }

    /** Вызывается при включении модуля. */
    public void b() {}

    /** Вызывается при выключении модуля. */
    public void c() {}

    /** Регистрация настроек модуля. */
    public void a(Setting... s) {
        for (Setting<?> x : s) {
            settings.add(x);
            SettingStore.load(name, x);
        }
    }

    public boolean m() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        SettingStore.setEnabled(name, value);
        if (value) {
            EventBus.register(this);
            b();
        } else {
            EventBus.unregister(this);
            c();
        }
        if (aM_.player != null && key != null) {
            aM_.player.sendMessage(Text.literal(name + (value ? " §aON" : " §cOFF")), true);
        }
    }

    /** Применить сохранённое состояние при запуске игры. */
    public void applyInitial() {
        if (enabled) {
            EventBus.register(this);
            b();
        }
    }
}
