package aethereal.core;

import aethereal.config.ModuleProcessor;
import aethereal.config.ThemeProcessor;
import aethereal.friend.FriendProcessor;
import aethereal.handler.HandlerProcessor;
import aethereal.handler.RotationProcessor;

public class Processor_2 {
    private final FriendProcessor friend = new FriendProcessor();
    private final RotationProcessor rotation = new RotationProcessor();
    private final ThemeProcessor theme = new ThemeProcessor();
    private final HandlerProcessor handler = new HandlerProcessor();

    public FriendProcessor e() { return friend; }
    public RotationProcessor k() { return rotation; }
    public ThemeProcessor o() { return theme; }
    public ModuleProcessor t() { return ModuleProcessor.INSTANCE; }
    public HandlerProcessor v() { return handler; }
}
