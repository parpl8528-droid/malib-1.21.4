package aethereal.core;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ModuleRegister {
    String a();
    String b();
    Category c();
}
