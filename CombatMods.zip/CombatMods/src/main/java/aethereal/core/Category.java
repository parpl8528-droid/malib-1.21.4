package aethereal.core;

public enum Category { Combat, Movement, Player, Render, Misc }
