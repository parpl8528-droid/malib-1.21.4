package aethereal.core;

/** Приходит в начале каждого клиентского тика. */
public class GlobalEvent {
}
