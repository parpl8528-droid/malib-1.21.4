package aethereal.lib.log4j;

public class Logger_2 {
}
