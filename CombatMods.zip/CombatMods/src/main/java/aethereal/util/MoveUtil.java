package aethereal.util;

import aethereal.event.InputEvent;

public final class MoveUtil {
    private MoveUtil() {}

    /**
     * Коррекция движения. Мы вращаем настоящую камеру игрока,
     * поэтому направление движения и так совпадает с взглядом - ничего менять не нужно.
     */
    public static void a(InputEvent event, float yaw, int mode) {
    }
}
