package aethereal.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

public final class ServerUtil {
    private ServerUtil() {}

    public static class a {
        /** Расстояние до цели. */
        public static float a(LivingEntity e) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || e == null) return 0f;
            return mc.player.distanceTo(e);
        }
    }
}
