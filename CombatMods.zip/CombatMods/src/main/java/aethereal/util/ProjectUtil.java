package aethereal.util;

import org.joml.Vector2f;

public final class ProjectUtil {
    private ProjectUtil() {}

    public static Vector2f a(double x, double y, double z) {
        return new Vector2f(0f, 0f);
    }

    public static boolean a(Vector2f v) {
        return false;
    }
}
