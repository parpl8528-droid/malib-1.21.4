package aethereal.util;

public final class MathUtil {
    private MathUtil() {}

    /** Случайное число от a до b. */
    public static float a(float a, float b) {
        return a + (float) Math.random() * (b - a);
    }
}
