package aethereal.util;

public final class ChatUtil {
    private ChatUtil() {}

    /** Отладочный вывод оригинала - отключён. */
    public static void a(Object o) {
    }
}
