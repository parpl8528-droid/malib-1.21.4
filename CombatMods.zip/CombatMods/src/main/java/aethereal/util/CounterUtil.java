package aethereal.util;

public class CounterUtil {
    private long last = System.currentTimeMillis();

    /** Прошло ли ms миллисекунд с последнего сброса. */
    public boolean a(long ms) {
        return System.currentTimeMillis() - last >= ms;
    }

    public void b() {
        last = System.currentTimeMillis();
    }
}
