package aethereal.util;

import net.minecraft.client.MinecraftClient;

public final class Look {
    private Look() {}

    public static float b() {
        return MinecraftClient.getInstance().player == null ? 0f : MinecraftClient.getInstance().player.getYaw();
    }

    public static float c() {
        return MinecraftClient.getInstance().player == null ? 0f : MinecraftClient.getInstance().player.getPitch();
    }
}
