package aethereal.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Поиск предметов. Возвращает индекс слота инвентаря (0..35) или -1. */
public final class InventoryUtil {
    private InventoryUtil() {}

    private static int find(Item item, boolean plainOnly) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return -1;
        PlayerInventory inv = mc.player.getInventory();
        // сначала основной инвентарь, потом хотбар
        for (int pass = 0; pass < 2; pass++) {
            int from = pass == 0 ? 9 : 0;
            int to = pass == 0 ? 36 : 9;
            for (int i = from; i < to; i++) {
                ItemStack s = inv.getStack(i);
                if (s.isOf(item) && (!plainOnly || !s.hasGlint())) return i;
            }
        }
        return -1;
    }

    public static int a(Item item, boolean flag, boolean plainOnly) {
        return find(item, plainOnly);
    }

    public static int b(Item item) {
        return find(item, false);
    }

    public static int c(Item item) {
        return find(item, false);
    }
}
