package aethereal.event;

import aethereal.render.Draw2DProcessor;
import net.minecraft.client.util.math.MatrixStack;

/** Визуальные эффекты оригинала в этой сборке не рисуются, событие не отправляется. */
public class DrawEvent {
    public boolean b() { return false; }
    public boolean c() { return false; }
    public Draw2DProcessor d() { return new Draw2DProcessor(); }
    public float g() { return 0f; }
    public MatrixStack h() { return new MatrixStack(); }
}
