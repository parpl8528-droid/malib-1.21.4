package aethereal.event;

public class TickEvent {
}
