package aethereal.event;

import net.minecraft.client.input.Input;

public class InputEvent {
    private final Input input;

    public InputEvent(Input input) {
        this.input = input;
    }

    public float forward() { return input.movementForward; }
    public float sideways() { return input.movementSideways; }

    /** Выставить движение вперёд/назад. */
    public void a(float v) { input.movementForward = v; }

    /** Выставить движение вбок. */
    public void b(float v) { input.movementSideways = v; }
}
