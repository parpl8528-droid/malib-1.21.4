package aethereal.event;

public class WillLandEvent {
    private final boolean willLand;

    public WillLandEvent(boolean willLand) {
        this.willLand = willLand;
    }

    public boolean b() {
        return willLand;
    }
}
