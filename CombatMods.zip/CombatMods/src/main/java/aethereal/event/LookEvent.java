package aethereal.event;

public class LookEvent {
}
