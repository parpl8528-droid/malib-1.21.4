package combatmods.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Util() {}

    // ---------- цели ----------

    /** Подходит ли сущность под фильтр целей из конфига. */
    public static boolean isValidTarget(Entity e) {
        if (!(e instanceof LivingEntity le)) return false;
        ClientPlayerEntity self = mc.player;
        if (self == null || e == self) return false;
        if (!le.isAlive() || le.isSpectator() || le instanceof ArmorStandEntity) return false;
        Config c = Config.INSTANCE;
        if (e instanceof PlayerEntity) return c.targetPlayers;
        if (e instanceof Monster) return c.targetHostile;
        return c.targetPassive;
    }

    /** Ближайшая к глазам точка хитбокса цели. */
    public static Vec3d closestPoint(Vec3d from, Box box) {
        return new Vec3d(
                MathHelper.clamp(from.x, box.minX, box.maxX),
                MathHelper.clamp(from.y, box.minY, box.maxY),
                MathHelper.clamp(from.z, box.minZ, box.maxZ));
    }

    /** Точка, в которую целимся: по центру цели, но на высоте глаз, если они попадают в хитбокс. */
    public static Vec3d aimPoint(Entity e) {
        Box b = e.getBoundingBox();
        Vec3d eye = mc.player.getEyePos();
        return new Vec3d(
                (b.minX + b.maxX) / 2.0,
                MathHelper.clamp(eye.y, b.minY + 0.1, b.maxY - 0.1),
                (b.minZ + b.maxZ) / 2.0);
    }

    public static double distanceTo(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        return eye.distanceTo(closestPoint(eye, e.getBoundingBox()));
    }

    /** Ближайшая подходящая цель в радиусе range (по хитбоксу). */
    public static Optional<LivingEntity> nearestTarget(double range, boolean throughWalls) {
        if (mc.world == null || mc.player == null) return Optional.empty();
        Box area = mc.player.getBoundingBox().expand(range + 2.0);
        List<LivingEntity> list = mc.world.getEntitiesByClass(LivingEntity.class, area, Util::isValidTarget);
        return list.stream()
                .filter(e -> distanceTo(e) <= range)
                .filter(e -> throughWalls || mc.player.canSee(e))
                .min(Comparator.comparingDouble(Util::distanceTo));
    }

    // ---------- вращение ----------

    public static float yawTo(Vec3d from, Vec3d to) {
        return (float) (MathHelper.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90.0f;
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        return (float) -(MathHelper.atan2(dy, Math.hypot(dx, dz)) * 180.0 / Math.PI);
    }

    /** Суммарная угловая ошибка до точки. */
    public static float angleError(Vec3d to) {
        Vec3d eye = mc.player.getEyePos();
        float dy = MathHelper.wrapDegrees(yawTo(eye, to) - mc.player.getYaw());
        float dp = pitchTo(eye, to) - mc.player.getPitch();
        return (float) Math.hypot(dy, dp);
    }

    /** Плавно довернуть камеру к точке, максимум maxStep градусов за тик. */
    public static void rotateTowards(Vec3d to, float maxStep) {
        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        float dyaw = MathHelper.wrapDegrees(yawTo(eye, to) - p.getYaw());
        float dpitch = pitchTo(eye, to) - p.getPitch();
        dyaw = MathHelper.clamp(dyaw, -maxStep, maxStep);
        dpitch = MathHelper.clamp(dpitch, -maxStep, maxStep);
        p.setYaw(p.getYaw() + dyaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpitch, -90f, 90f));
    }

    // ---------- бой ----------

    public static boolean isWeapon(ItemStack s) {
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    public static void attack(Entity target) {
        if (mc.interactionManager == null || mc.player == null) return;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
