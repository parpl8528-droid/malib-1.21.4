package combatmods.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Настройки всех модулей. Файл: config/combatmods.json (правится любым текстовым редактором).
 */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("combatmods.json");

    public static Config INSTANCE = new Config();

    // ---- общее ----
    public boolean hud = true;
    public Map<String, Boolean> enabled = new HashMap<>();

    // ---- цели (Aura / AimAssist / TriggerBot) ----
    public boolean targetPlayers = true;
    public boolean targetHostile = true;
    public boolean targetPassive = false;

    // ---- Aura ----
    public double auraRange = 3.0;          // дальность до хитбокса
    public float auraRotateSpeed = 45f;     // макс. градусов за тик
    public float auraCooldown = 0.92f;      // с какой готовностью удара бить (0..1)
    public boolean auraThroughWalls = false;
    public boolean auraOnlyWeapon = true;   // бить только с мечом/топором/булавой в руке

    // ---- AimAssist ----
    public double aimRange = 4.5;
    public float aimFov = 70f;              // угол обзора поиска цели
    public float aimSpeed = 6f;             // градусов за тик
    public boolean aimOnlyWhileAttacking = true; // только пока зажата кнопка атаки
    public boolean aimOnlyWeapon = false;

    // ---- TriggerBot ----
    public float triggerCooldown = 0.92f;
    public boolean triggerOnlyWeapon = true;
    public boolean triggerSkipWhenUsingItem = true;

    // ---- AutoTotem ----
    public float totemHealth = 20f;         // ставить тотем, когда здоровье <= этого (20 = всегда)
    public int totemDelay = 2;              // тиков между действиями

    // ---- AutoArmor ----
    public int armorDelay = 3;
    public boolean armorKeepElytra = true;

    // ---- AutoSwap ----
    public String swapMode = "SWORD";       // SWORD | AXE | MACE

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) {
                    INSTANCE = c;
                }
            }
        } catch (Exception e) {
            System.err.println("[CombatMods] Не удалось прочитать конфиг, использую стандартный: " + e);
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (IOException e) {
            System.err.println("[CombatMods] Не удалось сохранить конфиг: " + e);
        }
    }
}
