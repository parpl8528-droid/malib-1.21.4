package combatmods.core;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

/**
 * Базовый модуль. У каждого модуля свой кейбинд в Настройки -> Управление -> "Combat Mods".
 * Там можно назначить любую клавишу или кнопку мыши.
 */
public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String id;
    public final String displayName;
    public final KeyBinding key;

    private boolean enabled;

    protected Module(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
        this.key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combatmods." + id,
                InputUtil.Type.KEYSYM,
                InputUtil.UNKNOWN_KEY.getCode(),   // по умолчанию не назначено - выбираешь сам
                "key.categories.combatmods"
        ));
        this.enabled = Config.INSTANCE.enabled.getOrDefault(id, false);
    }

    /** Вызывается каждый клиентский тик, пока модуль включён и игрок в мире. */
    public abstract void onTick();

    /** Строка справа от имени в HUD (режим и т.п.), может быть null. */
    public String hudInfo() {
        return null;
    }

    protected void onEnable() {}
    protected void onDisable() {}

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        Config.INSTANCE.enabled.put(id, value);
        Config.save();
        if (value) onEnable(); else onDisable();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(displayName + (value ? " §aON" : " §cOFF")), true);
        }
    }
}
