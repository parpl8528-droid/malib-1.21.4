package combatmods.core;

import combatmods.CombatMods;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Отдельный HUD: список включённых модулей в правом верхнем углу.
 * Включается/выключается своим кейбиндом ("Toggle HUD") и флагом hud в конфиге.
 */
public final class Hud {
    private static final int[] COLORS = {0xFF55FFFF, 0xFF55FF55, 0xFFFFFF55, 0xFFFF55FF, 0xFFFFAA00, 0xFFFF5555};

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.INSTANCE.hud || mc.player == null || mc.options.hudHidden || mc.options.debugEnabled) return;

        TextRenderer tr = mc.textRenderer;
        int screenW = ctx.getScaledWindowWidth();

        List<String> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        int idx = 0;
        for (Module m : CombatMods.MODULES) {
            int color = COLORS[idx++ % COLORS.length];
            if (!m.isEnabled()) continue;
            String info = m.hudInfo();
            lines.add(info == null ? m.displayName : m.displayName + " §7[" + info + "]");
            colors.add(color);
        }
        // сортировка по ширине, длинные сверху
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) order.add(i);
        order.sort(Comparator.comparingInt((Integer i) -> tr.getWidth(lines.get(i))).reversed());

        int y = 4;
        for (int i : order) {
            String s = lines.get(i);
            int w = tr.getWidth(s);
            int x = screenW - w - 4;
            ctx.fill(x - 2, y - 1, screenW - 2, y + tr.fontHeight, 0x90000000);
            ctx.fill(screenW - 3, y - 1, screenW - 2, y + tr.fontHeight, colors.get(i));
            ctx.drawTextWithShadow(tr, s, x, y, colors.get(i));
            y += tr.fontHeight + 2;
        }
    }
}
