package combatmods;

import combatmods.core.Config;
import combatmods.core.Hud;
import combatmods.core.Module;
import combatmods.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.List;

public class CombatMods implements ClientModInitializer {
    public static Aura AURA;
    public static List<Module> MODULES;

    private static KeyBinding hudKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        AURA = new Aura();
        MODULES = List.of(
                AURA,
                new AimAssist(),
                new TriggerBot(),
                new AutoTotem(),
                new AutoArmor(),
                new AutoSwap()
        );

        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combatmods.hud", InputUtil.Type.KEYSYM, InputUtil.UNKNOWN_KEY.getCode(), "key.categories.combatmods"));

        ClientTickEvents.END_CLIENT_TICK.register(CombatMods::tick);
        HudRenderCallback.EVENT.register(Hud::render);
    }

    private static void tick(MinecraftClient mc) {
        while (hudKey.wasPressed()) {
            Config.INSTANCE.hud = !Config.INSTANCE.hud;
            Config.save();
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("HUD " + (Config.INSTANCE.hud ? "§aON" : "§cOFF")), true);
            }
        }

        for (Module m : MODULES) {
            while (m.key.wasPressed()) {
                m.toggle();
            }
        }

        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        for (Module m : MODULES) {
            if (m.isEnabled()) {
                m.onTick();
            }
        }
    }
}
