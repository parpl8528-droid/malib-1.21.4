package combatmods.modules;

import combatmods.core.Config;
import combatmods.core.Module;
import combatmods.core.Util;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** AimAssist: мягко подтягивает прицел к цели в поле зрения, не бьёт сам. */
public class AimAssist extends Module {
    public AimAssist() {
        super("aimassist", "AimAssist");
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        Config c = Config.INSTANCE;
        if (c.aimOnlyWhileAttacking && !mc.options.attackKey.isPressed()) return;
        if (c.aimOnlyWeapon && !Util.isWeapon(mc.player.getMainHandStack())) return;

        Box area = mc.player.getBoundingBox().expand(c.aimRange + 2.0);
        List<LivingEntity> list = mc.world.getEntitiesByClass(LivingEntity.class, area, Util::isValidTarget);

        Optional<LivingEntity> best = list.stream()
                .filter(e -> Util.distanceTo(e) <= c.aimRange)
                .filter(e -> mc.player.canSee(e))
                .filter(e -> Util.angleError(Util.aimPoint(e)) <= c.aimFov)
                .min(Comparator.comparingDouble(e -> Util.angleError(Util.aimPoint(e))));
        if (best.isEmpty()) return;

        Vec3d aim = Util.aimPoint(best.get());
        // чем ближе прицел к цели, тем мягче доводка
        float err = Util.angleError(aim);
        float step = Math.min(c.aimSpeed, Math.max(0.5f, err * 0.35f));
        Util.rotateTowards(aim, step);
    }
}
