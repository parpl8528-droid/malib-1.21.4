package combatmods.modules;

import combatmods.core.Config;
import combatmods.core.Module;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** AutoArmor: надевает лучшую броню из инвентаря. */
public class AutoArmor extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private int cooldown;

    public AutoArmor() {
        super("autoarmor", "AutoArmor");
    }

    /** Оценка брони: защита + стойкость (0 если это не броня). */
    private static double score(ItemStack s) {
        if (s.isEmpty()) return -1;
        AttributeModifiersComponent comp = s.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        double v = 0;
        for (var entry : comp.modifiers()) {
            if (entry.attribute() == EntityAttributes.ARMOR) v += entry.modifier().value();
            else if (entry.attribute() == EntityAttributes.ARMOR_TOUGHNESS) v += entry.modifier().value() * 0.5;
        }
        return v;
    }

    private static int armorSlotIndex(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> 5;
            case CHEST -> 6;
            case LEGS -> 7;
            default -> 8;
        };
    }

    @Override
    public void onTick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.currentScreen instanceof HandledScreen<?> && !(mc.currentScreen instanceof InventoryScreen)) return;

        Config c = Config.INSTANCE;
        PlayerScreenHandler handler = mc.player.playerScreenHandler;

        for (EquipmentSlot slot : SLOTS) {
            ItemStack worn = mc.player.getEquippedStack(slot);
            if (c.armorKeepElytra && slot == EquipmentSlot.CHEST && worn.isOf(Items.ELYTRA)) continue;
            double wornScore = score(worn);

            int bestSlot = -1;
            double bestScore = Math.max(wornScore, 0);   // кандидат должен быть строго лучше и > 0
            for (int i = 9; i <= 44; i++) {
                ItemStack st = handler.getSlot(i).getStack();
                EquippableComponent eq = st.get(DataComponentTypes.EQUIPPABLE);
                if (eq == null || eq.slot() != slot) continue;
                double sc = score(st);
                if (sc > bestScore) {
                    bestScore = sc;
                    bestSlot = i;
                }
            }
            if (bestSlot == -1) continue;

            int armorIdx = armorSlotIndex(slot);
            if (worn.isEmpty()) {
                // пустой слот: shift-клик сам переносит броню на место
                mc.interactionManager.clickSlot(handler.syncId, bestSlot, 0, SlotActionType.QUICK_MOVE, mc.player);
            } else {
                // замена: берём новую -> кладём на слот брони -> старую возвращаем на освободившееся место
                mc.interactionManager.clickSlot(handler.syncId, bestSlot, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(handler.syncId, armorIdx, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(handler.syncId, bestSlot, 0, SlotActionType.PICKUP, mc.player);
            }
            cooldown = c.armorDelay;
            return; // одно действие за раз
        }
    }
}
