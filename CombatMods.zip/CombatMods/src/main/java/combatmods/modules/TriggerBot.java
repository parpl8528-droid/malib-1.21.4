package combatmods.modules;

import combatmods.core.Config;
import combatmods.core.Module;
import combatmods.core.Util;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** TriggerBot: бьёт автоматически, когда прицел наведён на цель и удар заряжен. */
public class TriggerBot extends Module {
    public TriggerBot() {
        super("triggerbot", "TriggerBot");
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        Config c = Config.INSTANCE;
        if (c.triggerOnlyWeapon && !Util.isWeapon(mc.player.getMainHandStack())) return;
        if (c.triggerSkipWhenUsingItem && mc.player.isUsingItem()) return;

        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;
        EntityHitResult hit = (EntityHitResult) mc.crosshairTarget;
        if (!Util.isValidTarget(hit.getEntity())) return;

        if (mc.player.getAttackCooldownProgress(0.5f) >= c.triggerCooldown) {
            Util.attack(hit.getEntity());
        }
    }
}
