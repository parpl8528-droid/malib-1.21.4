package combatmods.modules;

import combatmods.CombatMods;
import combatmods.core.Config;
import combatmods.core.Module;
import combatmods.core.Util;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** AutoSwap: когда рядом есть цель (прицел или Aura) - берёт в руку нужное оружие из хотбара. */
public class AutoSwap extends Module {
    public AutoSwap() {
        super("autoswap", "AutoSwap");
    }

    private static boolean matches(ItemStack s, String mode) {
        return switch (mode) {
            case "AXE" -> s.isIn(ItemTags.AXES);
            case "MACE" -> s.isOf(Items.MACE);
            default -> s.isIn(ItemTags.SWORDS);
        };
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;

        boolean haveTarget = CombatMods.AURA.getTarget() != null;
        if (!haveTarget && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            haveTarget = Util.isValidTarget(((EntityHitResult) mc.crosshairTarget).getEntity());
        }
        if (!haveTarget) return;

        String mode = Config.INSTANCE.swapMode;
        var inv = mc.player.getInventory();
        if (matches(inv.getStack(inv.selectedSlot), mode)) return;

        for (int i = 0; i < 9; i++) {
            if (matches(inv.getStack(i), mode)) {
                inv.selectedSlot = i;
                return;
            }
        }
    }

    @Override
    public String hudInfo() {
        return Config.INSTANCE.swapMode;
    }
}
