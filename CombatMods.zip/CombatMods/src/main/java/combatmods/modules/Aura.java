package combatmods.modules;

import combatmods.core.Config;
import combatmods.core.Module;
import combatmods.core.Util;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/** Aura: сама наводится на ближайшую цель и бьёт, когда удар заряжен. */
public class Aura extends Module {
    private LivingEntity target;

    public Aura() {
        super("aura", "Aura");
    }

    public LivingEntity getTarget() {
        return isEnabled() ? target : null;
    }

    @Override
    protected void onDisable() {
        target = null;
    }

    @Override
    public void onTick() {
        target = null;
        if (mc.currentScreen != null) return;
        Config c = Config.INSTANCE;
        if (c.auraOnlyWeapon && !Util.isWeapon(mc.player.getMainHandStack())) return;

        Optional<LivingEntity> found = Util.nearestTarget(c.auraRange, c.auraThroughWalls);
        if (found.isEmpty()) return;
        target = found.get();

        Vec3d aim = Util.aimPoint(target);
        Util.rotateTowards(aim, c.auraRotateSpeed);

        // бьём только когда прицел уже почти на цели и удар заряжен
        if (Util.angleError(aim) < 12f
                && mc.player.getAttackCooldownProgress(0.5f) >= c.auraCooldown
                && Util.distanceTo(target) <= c.auraRange) {
            Util.attack(target);
        }
    }

    @Override
    public String hudInfo() {
        return target != null ? target.getName().getString() : null;
    }
}
