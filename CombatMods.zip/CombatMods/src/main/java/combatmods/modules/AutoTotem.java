package combatmods.modules;

import combatmods.core.Config;
import combatmods.core.Module;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** AutoTotem: держит тотем бессмертия во второй руке. */
public class AutoTotem extends Module {
    private int cooldown;

    public AutoTotem() {
        super("autototem", "AutoTotem");
    }

    @Override
    public void onTick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        // не лезем в сундуки/печки, только в обычный инвентарь или без экрана
        if (mc.currentScreen instanceof HandledScreen<?> && !(mc.currentScreen instanceof InventoryScreen)) return;

        Config c = Config.INSTANCE;
        if (mc.player.getHealth() > c.totemHealth) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        var handler = mc.player.playerScreenHandler;
        // слоты 9..35 - инвентарь, 36..44 - хотбар
        for (int slot = 9; slot <= 44; slot++) {
            if (handler.getSlot(slot).getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                // кнопка 40 = обмен с левой рукой
                mc.interactionManager.clickSlot(handler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
                cooldown = c.totemDelay;
                return;
            }
        }
    }
}
