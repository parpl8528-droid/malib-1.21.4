# Combat Mods (Fabric 1.21.4)

Модули: Aura, AimAssist, TriggerBot, AutoTotem, AutoArmor, AutoSwap + отдельный HUD.

## Управление
Настройки -> Управление -> категория **Combat Mods**. Каждому модулю и HUD можно назначить
любую клавишу или кнопку мыши. Нажатие = вкл/выкл.

## Настройки
`.minecraft/config/combatmods.json` (создаётся при первом запуске): дальность, скорость, цели и т.д.

## Сборка
- Локально: `gradle build` (Java 21), jar в `build/libs/`.
- Без компьютера: залить папку в GitHub-репозиторий -> вкладка Actions -> build -> Artifacts -> combatmods-jar.
